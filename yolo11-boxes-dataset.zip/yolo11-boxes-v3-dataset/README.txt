YOLO11 blue/red box detection dataset — version 3

images/: 148 images in one folder
labels/: 148 matching YOLO TXT files in one folder
train.txt: 125 images (56 positive + 69 background)
val.txt: 23 images (8 positive + 15 background)
data.yaml: change path to the absolute extracted folder location
manifest.json: source, split, and reviewed annotation provenance

Classes: 0 = blue_box, 1 = red_box. No bag/person/background class is added.
Positive labels use class_id center_x center_y width height, normalized.
Background-only images have empty TXT files.

Added: one blue-box photo and ten red-box frames sampled one second apart from
one video. All receive exactly one manually reviewed block label, not copied
model predictions. The blue bag and person in red salwar receive no labels.
Tight axis-aligned rectangles enclose all visible block surfaces. Because a
rectangle encloses an angled object, some background/occluding fingers can
remain within its corner regions; that does not make the person a labelled object.

Two bag-only and ten clothing-only crops contain no blocks and use empty labels.
All derivatives of the new photo/video stay in training. The original darker
corridor recordings remain held out. New examples are training regressions,
not independent test data. Adjacent video frames are correlated.
