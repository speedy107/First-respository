YOLO11 blue/red box detection dataset, version 2

images/: 125 images in one folder
labels/: matching YOLO TXT files in one folder
train.txt: 102 training images (45 box images + 57 background-only images)
val.txt: 23 validation images (8 box images + 15 background-only images)
data.yaml: update path to the absolute extracted folder location
manifest.json: source/split/annotation provenance

Classes: 0 = blue_box, 1 = red_box. No third background class is added.
Background-only images have empty label files: no boxes are present.
Positive format: class_id center_x center_y width height, normalized.

The added background examples were cropped outside the reviewed target boxes
from the supplied videos and visually checked. Crops retaining any part of the
target were excluded. People, bags, chairs and clutter are negative examples.
All derivatives of a source recording stay in the same split; the darker
corridor recordings remain excluded from training. Validation backgrounds are
mostly walls/floors; they are not a strong independent test of clothing/bags.

Version 2 addresses known false positives found in those source backgrounds.
Some difficult negatives were mined using version 1 predictions; improved
results on these same images are training regressions, not proof of performance
on new scenes. New examples of the user's red salwar and blue bag are still
needed to test those particular failures. No sky class or size measurement.
