# Blue/red box detector — version 4

Adds four unique photos of red chairs beside blocks, including three stacked
blue-over-red views. One exact duplicate upload was removed (SHA256).
Each physical block has its own manually reviewed axis-aligned rectangle:
seven labels in four original scenes. Labels enclose visible top/side/front
surfaces. Occluded red blocks use their visible extent. The rectangle around
an angled/occluded object can contain blue block pixels or background in its
corners; this is detection, not pixel segmentation. Chairs receive no labels.

Four detail crops retain all objects and correctly transformed labels. Six
visually reviewed chair-only crops have empty labels and contain no blocks.
All derivatives of this new scene remain in training.

Dataset: 162 image/label pairs, single images/ and labels/ folders.
Training: 139 images (64 positive images, 75 background images).
Validation: 23 images (8 positives, 15 backgrounds), original held-out videos.
Fine-tuning from V3: 33 epochs completed; epoch 31 selected.
Input is fixed 320x320 RGB letterbox, /255 normalization, no objectness channel.
Output [1,6,2100], class-aware NMS IoU 0.45, default confidence 0.35.

Checkpoint selection checks every object separately and rejects unmatched
detections on 60 regression images: original validation, V3 bag/clothing
examples, and V4 chair/stack examples. The browser repeats these checks at
0.35, verifies rendered rectangles overlap manual labels by IoU >= 0.6,
and exercises camera start/stop, Save frame, and error handling.
See checkpoint-regressions.json and browser-regressions.json for evidence.
New examples are training regressions; success does not establish accuracy
on unfamiliar chairs or new stacked views. Phone speed remains unmeasured.

metrics.json contains fixed-square validation and ONNX numerical checks.
manual-labels.json, negative-labels.json and duplicates.json record provenance.
Training scripts require the previous checkpoint/source images at their
documented paths; the dataset is independently usable after editing data.yaml.

Install ultralytics==8.3.221 with compatible PyTorch, then:

    python predict.py image.jpg
    python predict.py video.mp4

Use rect=False to match browser deployment. Class 0=blue_box, 1=red_box.
Only these classes are trained; no physical dimension measurement.

YOLO labels: class_id center_x center_y width height, normalized to image size.
Background-only TXT files are empty. Edit data.yaml path after extraction.
