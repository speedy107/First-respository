YOLO11 blue/red box detection dataset

images/: all 53 images in one folder
labels/: 53 matching YOLO TXT files in one folder
train.txt: 45 images (24 blue, 21 red)
val.txt: 8 images (4 blue, 4 red)
data.yaml: Ultralytics dataset configuration
manifest.json: source frame, class, split, and reviewed annotation provenance

Classes: 0 = blue_box, 1 = red_box.
Label format: class_id center_x center_y width height (normalized coordinates).
Update data.yaml path to the absolute extracted folder location.

Frames were sampled two seconds apart. Labels were proposed with color masks
and visually reviewed/corrected. Some unclear or heavily cropped examples
were excluded. Each recording belongs to exactly one split. The two darker
corridor clips (WA0031 red and WA0033 blue) are held out for validation;
all other clips supply training examples. Several backgrounds share the same
room. Validation is a small model-selection set, not an independent final test.

This starter dataset does not cover empty scenes, multiple boxes together,
or broad lighting/environment changes. Collect new recordings to establish
real-world accuracy. Color identifies the class; physical dimensions are
not measured. No sky/half-red-half-blue class is included.
