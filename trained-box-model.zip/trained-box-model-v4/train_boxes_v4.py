"""Fine-tune manually labelled chair/stack examples with square deployment validation."""
import os
from pathlib import Path
root=Path(__file__).resolve().parent
os.environ.setdefault('YOLO_CONFIG_DIR',str(root/'ultralytics-config'))
os.environ.setdefault('OMP_NUM_THREADS','4');os.environ.setdefault('MKL_NUM_THREADS','4')
import torch
from ultralytics import YOLO
from ultralytics.models.yolo.detect.train import DetectionTrainer
from ultralytics.data import build_yolo_dataset
from ultralytics.utils.torch_utils import unwrap_model

class SquareValidationTrainer(DetectionTrainer):
 def build_dataset(self,img_path,mode='train',batch=None):
  stride=max(int(unwrap_model(self.model).stride.max() if self.model else 0),32)
  return build_yolo_dataset(self.args,img_path,batch,self.data,mode=mode,rect=False,stride=stride)

def main():
 torch.set_num_threads(4);torch.set_num_interop_threads(1)
 model=YOLO(str(root/'trained-box-model-v3'/'boxes-yolo11n.pt'))
 model.train(trainer=SquareValidationTrainer,data=str(root/'yolo11-boxes-v4-dataset'/'data.yaml'),epochs=45,patience=20,save_period=5,imgsz=320,rect=False,batch=8,device='cpu',workers=0,project=str(root/'runs'),name='boxes-yolo11n-v4',seed=45,deterministic=True,optimizer='AdamW',lr0=.0002,lrf=.01,weight_decay=.0005,warmup_epochs=1,hsv_h=0,hsv_s=.2,hsv_v=.25,degrees=8,translate=.08,scale=.25,fliplr=.5,flipud=0,mosaic=.2,close_mosaic=10,mixup=0,amp=False,cache='ram',plots=True)
if __name__=='__main__':main()
