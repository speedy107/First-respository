"""Manual visible-object envelopes; all new-scene derivatives stay in train."""
from pathlib import Path
import json, shutil, hashlib
from PIL import Image, ImageDraw, ImageOps

root=Path(__file__).parent
source=Path('/tmp/codex-remote-attachments/01a1113d-1c57-70c4-8282-dffe424da034/98ed6aee-c740-4beb-95e5-622143ab29d4')
out=root/'yolo11-boxes-v4-dataset'; review=root/'review-v4'
shutil.copytree(root/'yolo11-boxes-v3-dataset',out,dirs_exist_ok=True)
rows=json.loads((out/'manifest.json').read_text())
# Coordinates reviewed on original images, including visible top/side surfaces.
# Occluded red blocks use the envelope of visible red surfaces, not an invented
# hidden full cube. Rectangular corners can contain the foreground blue block.
annotations={
 '1-1000340791.jpg':[(1,[781,361,1178,783])],
 '2-1000340788.jpg':[(0,[157,201,630,668]),(1,[230,573,634,955])],
 '3-1000340787.jpg':[(0,[442,374,936,839]),(1,[470,725,827,1068])],
 '5-1000340785.jpg':[(0,[440,573,606,726]),(1,[454,705,579,829])],
}
new=[]; tiles=[]
def add(name,im,objects,original,crop=None):
 w,h=im.size
 im.save(out/'images'/(name+'.jpg'),quality=95)
 lines=[]
 for obj in objects:
  x1,y1,x2,y2=obj['box_xyxy'];assert 0<=x1<x2<=w and 0<=y1<y2<=h
  lines.append(f"{obj['class_id']} {(x1+x2)/2/w:.6f} {(y1+y2)/2/h:.6f} {(x2-x1)/w:.6f} {(y2-y1)/h:.6f}")
 (out/'labels'/(name+'.txt')).write_text('\n'.join(lines)+('\n' if lines else ''))
 r={'export_name':name,'image':str(source/original),'source_group':'v4_chair_stack_scene','split':'train','image_size':[w,h],'objects':objects,'class_id':objects[0]['class_id'] if objects else None,'status':'manually_reviewed','source_file':original}
 if crop:r['crop_xyxy']=crop
 rows.append(r);new.append(r)
 rendered=im.copy();d=ImageDraw.Draw(rendered)
 for obj in objects:
  d.rectangle(obj['box_xyxy'],outline=(0,255,255),width=4)
  d.text((obj['box_xyxy'][0]+5,obj['box_xyxy'][1]+5),'BLUE BOX' if obj['class_id']==0 else 'RED BOX',fill='white',stroke_width=2,stroke_fill='black')
 thumb=ImageOps.contain(rendered,(460,600));tile=Image.new('RGB',(480,640),'white');tile.paste(thumb,((480-thumb.width)//2,0));ImageDraw.Draw(tile).text((8,615),name,fill='black');tiles.append(tile)

for filename,boxes in annotations.items():
 im=ImageOps.exif_transpose(Image.open(source/filename))
 objects=[{'class_id':c,'box_xyxy':b} for c,b in boxes]
 add('new_v4_'+filename.split('-')[1].split('.')[0],im,objects,filename)

# Retain stack geometry in close views as well as the original full scenes.
positive_crops={
 '1-1000340791.jpg':[130,240,1240,900],
 '2-1000340788.jpg':[155,185,655,980],
 '3-1000340787.jpg':[437,356,945,1095],
 '5-1000340785.jpg':[410,535,635,850],
}
for filename,crop in positive_crops.items():
 a,b,c,d=crop; im=Image.open(source/filename).crop(crop)
 objects=[{'class_id':cls,'box_xyxy':[x1-a,y1-b,x2-a,y2-b]} for cls,(x1,y1,x2,y2) in annotations[filename]]
 add('new_v4_detail_'+filename.split('-')[1].split('.')[0],im,objects,filename,crop)
canvas=Image.new('RGB',(1920,1280),'white')
for j,t in enumerate(tiles):canvas.paste(t,((j%4)*480,(j//4)*640))
canvas.save(review/'manual-labels.jpg',quality=95)

tiles=[]
negative_crops=[
 ('1-1000340791.jpg','chair_large',[0,0,770,960]),
 ('2-1000340788.jpg','chair_partial',[0,65,154,664]),
 ('3-1000340787.jpg','chair_close',[0,280,439,1250]),
 ('5-1000340785.jpg','chairs_wide',[0,520,435,1100]),
 ('5-1000340785.jpg','chair_back',[269,540,439,895]),
 ('5-1000340785.jpg','chair_foreground',[0,613,315,1085]),
]
for filename,kind,crop in negative_crops:
 a,b,c,d=crop
 for _,(x1,y1,x2,y2) in annotations[filename]:
  assert min(c,x2)<=max(a,x1) or min(d,y2)<=max(b,y1),'Negative contains target'
 add('new_v4_negative_'+kind,Image.open(source/filename).crop(crop),[],filename,crop)
canvas=Image.new('RGB',(1440,1280),'white')
for j,t in enumerate(tiles):canvas.paste(t,((j%3)*480,(j//3)*640))
canvas.save(review/'chair-negatives.jpg',quality=95)
(review/'manual-labels.json').write_text(json.dumps([r for r in new if r['objects']],indent=2))
(review/'negative-labels.json').write_text(json.dumps([r for r in new if not r['objects']],indent=2))
assert hashlib.sha256((source/'3-1000340787.jpg').read_bytes()).digest()==hashlib.sha256((source/'4-1000340786.jpg').read_bytes()).digest()
(review/'duplicates.json').write_text(json.dumps({'excluded':'4-1000340786.jpg','identical_to':'3-1000340787.jpg','method':'SHA256 exact duplicate'},indent=2))
(out/'manifest.json').write_text(json.dumps(rows,indent=2))
for split in ['train','val']:
 selected=[r for r in rows if r['split']==split]
 (out/(split+'.txt')).write_text(''.join('./images/'+r['export_name']+'.jpg\n' for r in selected))
 print(split,len(selected),'positive',sum(r['class_id'] is not None for r in selected),'background',sum(r['class_id'] is None for r in selected))
(out/'data.yaml').write_text(f'path: {out}\ntrain: train.txt\nval: val.txt\nnames:\n  0: blue_box\n  1: red_box\n')
for p in out.rglob('*.cache'):p.unlink()
