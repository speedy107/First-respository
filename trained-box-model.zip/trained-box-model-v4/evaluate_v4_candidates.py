"""Compare separate stacked objects and reject every unmatched detection."""
import os,json,argparse,csv
from pathlib import Path
root=Path(__file__).parent
os.environ['YOLO_CONFIG_DIR']=str(root/'ultralytics-config')
import torch
from ultralytics import YOLO

def iou(a,b):
 area=lambda b:max(0,b[2]-b[0])*max(0,b[3]-b[1])
 intersection=area([max(a[0],b[0]),max(a[1],b[1]),min(a[2],b[2]),min(a[3],b[3])])
 return intersection/(area(a)+area(b)-intersection+1e-9)

def targets(r,dataset):
 from PIL import Image
 w,h=Image.open(dataset/'images'/(r['export_name']+'.jpg')).size
 result=[]
 for line in (dataset/'labels'/(r['export_name']+'.txt')).read_text().splitlines():
  c,x,y,bw,bh=map(float,line.split())
  result.append({'class_id':int(c),'xyxy':[(x-bw/2)*w,(y-bh/2)*h,(x+bw/2)*w,(y+bh/2)*h]})
 return result

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--baseline-only',action='store_true');args=parser.parse_args()
 torch.set_num_threads(4)
 dataset=root/'yolo11-boxes-v4-dataset'
 rows=json.loads((dataset/'manifest.json').read_text())
 selected=[r for r in rows if r['split']=='val' or r['export_name'].startswith(('new_v3_','new_v4_'))]
 candidates={'v3':root/'trained-box-model-v3'/'boxes-yolo11n.pt'}
 if not args.baseline_only:
  run=root/'runs'/'boxes-yolo11n-v4'/'weights'
  candidates.update({p.stem:p for p in [run/'best.pt',run/'last.pt',*sorted(run.glob('epoch*.pt'))]})
 reports={}
 for name,weights in candidates.items():
  model=YOLO(str(weights))
  predictions=model.predict([str(dataset/'images'/(r['export_name']+'.jpg')) for r in selected],imgsz=320,rect=False,batch=8,device='cpu',conf=.25,iou=.45,verbose=False,stream=True)
  outcomes=[]
  for r,p in zip(selected,predictions):
   gt=targets(r,dataset)
   boxes=[{'class_id':int(b.cls.item()),'confidence':float(b.conf.item()),'xyxy':b.xyxy[0].tolist()} for b in p.boxes]
   thresholds={}
   for threshold in [.25,.35]:
    strong=[b for b in boxes if b['confidence']>=threshold];available=set(range(len(strong)));overlaps=[]
    for g in gt:
     options=[(iou(g['xyxy'],b['xyxy']),i) for i,b in enumerate(strong) if i in available and b['class_id']==g['class_id']]
     overlap,index=max(options,default=(0,-1));overlaps.append(overlap)
     if index>=0:available.remove(index)
    thresholds[str(threshold)]={'passed':len(strong)==len(gt) and all(v>=.5 for v in overlaps),'matched_ious':overlaps,'extra_detections':len(available)}
   outcomes.append({'image':r['export_name'],'split':r['split'],'targets':gt,'detections_at_0_25':boxes,'thresholds':thresholds})
  report={'outcomes':outcomes,'total':len(outcomes)}
  for t in ['0.25','0.35']:
   report[t]={'passed':sum(o['thresholds'][t]['passed'] for o in outcomes),'failed_images':[o['image'] for o in outcomes if not o['thresholds'][t]['passed']]}
  reports[name]=report;print(name,json.dumps({k:v for k,v in report.items() if k!='outcomes'}),flush=True)
 path=root/'review-v4'/('baseline-regressions.json' if args.baseline_only else 'checkpoint-regressions.json')
 path.write_text(json.dumps(reports,indent=2))
 if not args.baseline_only:
  passing=[n for n in candidates if n!='v3' and reports[n]['0.35']['passed']==len(selected)]
  assert passing,'No candidate passes the required regressions at 0.35'
  history=list(csv.DictReader((root/'runs'/'boxes-yolo11n-v4'/'results.csv').open()))
  def heldout_score(name):
   if name=='best':return max(float(r['metrics/mAP50-95(B)']) for r in history)
   epoch=len(history)-1 if name=='last' else int(name.removeprefix('epoch'))
   return float(history[epoch]['metrics/mAP50-95(B)'])
  # Among candidates with no regression, retain the strongest held-out score.
  passing.sort(key=lambda n:(reports[n]['0.25']['passed'],heldout_score(n)),reverse=True)
  choice=passing[0];(root/'review-v4'/'selected-checkpoint.txt').write_text(choice+'\n');print('Selected',choice)
if __name__=='__main__':main()
