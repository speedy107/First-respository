# Blue/red box detector — version 2

This update fine-tunes the original YOLO11 nano model with background-only
examples to reduce false positives. Classes remain 0 = blue_box, 1 = red_box.
Background images have empty label files; no extra background class is added.

Training: 45 box images + 57 background crops. Validation: 8 box images +
15 background crops from two separate held-out recordings. Fine-tuning stopped
after 24 epochs. The final epoch-24 checkpoint is deployed; the automatic best
checkpoint selected at epoch 9 did not pass the fixed-square browser regression.
All evaluation reported here uses the deployment's fixed 320x320 letterbox.

## Evidence and limits

- All eight held-out box images yielded one correctly classified detection.
- At confidence 0.35, V1 falsely detected boxes on 4 of 108 reviewed training-
  source background crops; V2 did so on 0. At 0.25 the counts were 5 and 0.
- Both versions rejected all 15 held-out background crops at these thresholds.
- Many of the 108 background crops were used in fine-tuning; this is a diagnostic
  training regression, not an independent generalization measurement. The
  held-out backgrounds are mainly plain walls/floors. These checks do not prove
  rejection of the user's red salwar or blue bag, which have not been supplied.
- Fixed-square validation mAP50: 99.5%; mAP50-95: 83.3%. These are small-set
  detection metrics, not real-world accuracy percentages.
- Chromium browser tests passed for all eight images, the known false-positive
  scenes, simulated live-camera updates, saving a raw frame, Stop, and errors.
  Actual iQOO Neo 6 speed and new-scene performance remain untested here.

## Files and usage

boxes-yolo11n.pt: Ultralytics checkpoint.
boxes-yolo11n.onnx: FP32, opset 17, fixed batch 1 / RGB 320x320 input.
model-spec.json: preprocessing, output decoding and class-aware NMS details.
metrics.json: fixed-square validation and ONNX verification results.
background-comparison.json: same-preprocessing V1/V2 diagnostic results.
false-positive-comparison.jpg: before/after known background mistakes.
training-settings.yaml / training-results.csv: fine-tuning configuration/history.

Install ultralytics==8.3.221 with compatible PyTorch, then run:

    python predict.py path/to/image.jpg
    python predict.py path/to/video.mp4

Annotated output is saved under predictions/boxes. Use fixed-square
preprocessing (rect=False) to match browser inference.

ONNX passed its structural check and numerical comparison with PyTorch on
23 inputs at rtol=0.001 and atol=0.001. Raw coordinate maximum absolute
variation was about 0.00220 pixels; see metrics.json for exact details.
Browser integration uses ONNX Runtime Web and class-aware NMS, not an API.
No sky class or millimeter measurement is included.
