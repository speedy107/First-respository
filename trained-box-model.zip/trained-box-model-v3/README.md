# Blue/red box detector — version 3

This update adds IMG_20261007_202141.jpg and ten one-second-spaced frames from
VID-20261008-WA0003.mp4. Each has exactly one manually reviewed label on the
actual block: one blue box in the photo and one red box in each video frame.
Model V2 predictions were not copied as ground-truth labels. The bag and person
in red clothing are unlabelled background, not additional classes. Tight axis-
aligned rectangles cover all visible block surfaces. Angled corners can still
contain background/occluding fingers within the rectangular envelope.

Two bag-only crops and ten red-clothing-only crops were visually reviewed to
contain no block pixels and added with empty label files. All images derived
from these two new inputs stay in training, never validation.

Dataset: 148 images. Training: 56 positive images + 69 backgrounds. Validation:
8 positive images + 15 backgrounds from the original held-out recordings.
The separate dataset ZIP has one images/ folder and one labels/ folder.

Fine-tuning: 31 epochs from V2 weights; automatic early stop. The epoch-16 best
checkpoint was selected. A custom DetectionTrainer subclass uses fixed-square
320x320 validation, matching browser deployment (no library files modified).

## Verified behavior

All 46 positive/background regression examples passed at confidence 0.35,
including all 11 new positives and 12 new negatives. This is a training-regression
check for the new inputs, not an independent measurement of unfamiliar views.
All eight held-out box images still produced correct labels. Fixed-square
validation mAP50 is 99.5%, mAP50-95 is 86.6%; the validation set remains small.

In Chromium at a mobile viewport, every new positive rendered exactly one
rectangle at the actual box with IoU at least 0.86 against the manual label.
All 12 new bag/clothing crops rendered zero boxes. Existing image/camera/error
regressions passed. A simulated camera feed using the original new video
produced 58 updates: one red box each time, no extra detections or JavaScript
errors. This clip was used for training; it is not independent evaluation.
Actual Android phone performance and new scenes remain untested here.

ONNX passed the structural check and numerical comparison against PyTorch on
23 held-out inputs with rtol=0.001, atol=0.001. Exact statistics are in metrics.json.

## Files and use

boxes-yolo11n.pt: Ultralytics checkpoint.
boxes-yolo11n.onnx: FP32, opset 17, fixed [1,3,320,320] RGB input.
model-spec.json: preprocessing, decoding and class-aware NMS details.
metrics.json / checkpoint-regressions.json: validation and regression evidence.
manual-labels.json / new-negative-labels.json: reviewed source annotation records.
train_boxes_v3.py: fine-tuning recipe (requires previous V2 checkpoint/dataset paths).
training-settings.yaml / training-results.csv: configuration and history.

Install ultralytics==8.3.221 with compatible PyTorch, then:

    python predict.py path/to/image.jpg
    python predict.py path/to/video.mp4

Use rect=False to match browser input. Annotated output goes to predictions/boxes.
Browser deployment uses ONNX Runtime Web on the phone; no video is uploaded.
Classes remain 0=blue_box, 1=red_box. No sky class or dimension measurement.
